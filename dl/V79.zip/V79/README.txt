V79 High Pigtails: Two high ties, each tail springing up and out before it falls; they swing as you move.

Project Arena 0.3.26, from the asset viewer: https://jendoebelin.github.io/ProjectArena-public/#V79

In this file:
  av_hair_9_m.glb
  av_hair_9_f.glb
  av_hair_9t_m.glb
  av_hair_9t_f.glb

The models are .glb (Blender: File > Import > glTF 2.0). Skinned parts carry the game's 9-bone avatar rig in its bind
pose; head parts are in head space (the origin between the eyes); gauntlets in the hand frame. Keep the material
names: they tell the game how to colour and light each part, and when you export from Blender (File > Export >
glTF 2.0, glTF Binary) tick Include > Custom Properties: the materials carry the game's exact settings there.

To make your own, start from the template pack (dl/project-arena-templates.zip on the viewer's page): its README says
what goes where. Send your file with the ID it replaces or adds to: a pull request (contrib/) or the Discord.

Art and sound: CC BY 4.0 (LICENSE-ASSETS.md in https://github.com/jendoebelin/ProjectArena-public).
