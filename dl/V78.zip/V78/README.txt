V78 Regalia: Gold plates with black filigree and a faceted jewel in the glow colour; in the game its fingers open on the trigger.

Project Arena 0.3.26, from the asset viewer: https://jendoebelin.github.io/ProjectArena-public/#V78

In this file:
  gauntlet_6_hand.glb
  gauntlet_6_cuff.glb
  gauntlet_6_fist.glb
  gauntlet_6_f0.glb
  gauntlet_6_f1.glb
  gauntlet_6_f2.glb
  gauntlet_6_f3.glb
  gauntlet_6_f4.glb

The models are .glb (Blender: File > Import > glTF 2.0). Skinned parts carry the game's 9-bone avatar rig in its bind
pose; head parts are in head space (the origin between the eyes); gauntlets in the hand frame. Keep the material
names: they tell the game how to colour and light each part, and when you export from Blender (File > Export >
glTF 2.0, glTF Binary) tick Include > Custom Properties: the materials carry the game's exact settings there.

To make your own, start from the template pack (dl/project-arena-templates.zip on the viewer's page): its README says
what goes where. Send your file with the ID it replaces or adds to: a pull request (contrib/) or the Discord.

Art and sound: CC BY 4.0 (LICENSE-ASSETS.md in https://github.com/jendoebelin/ProjectArena-public).
