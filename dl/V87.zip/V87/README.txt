V87 Goatee: A goatee: a mustache and a beard on the chin, fitted to each face, in the hair colour (0.3.27).

Project Arena 0.3.27, from the asset viewer: https://jendoebelin.github.io/ProjectArena-public/#V87

In this file:
  av_fhair_2_m.glb
  av_fhair_2_m1.glb
  av_fhair_2_m2.glb
  av_fhair_2_m3.glb
  av_fhair_2_m4.glb
  av_fhair_2_m5.glb
  av_fhair_2_f.glb
  av_fhair_2_f1.glb
  av_fhair_2_f2.glb
  av_fhair_2_f3.glb
  av_fhair_2_f4.glb
  av_fhair_2_f5.glb
  open_beard_fibres.png

The models are .glb (Blender: File > Import > glTF 2.0). Skinned parts carry the game's 9-bone avatar rig in its bind
pose; head parts are in head space (the origin between the eyes); gauntlets in the hand frame. Keep the material
names: they tell the game how to colour and light each part, and when you export from Blender (File > Export >
glTF 2.0, glTF Binary) tick Include > Custom Properties: the materials carry the game's exact settings there.

To make your own, start from the template pack (dl/project-arena-templates.zip on the viewer's page): its README says
what goes where. Send your file with the ID it replaces or adds to: a pull request (contrib/) or the Discord.

Art and sound: CC BY 4.0 (LICENSE-ASSETS.md in https://github.com/jendoebelin/ProjectArena-public).
