V26 Bike Shorts: Bike shorts with side panels in the trim colour.

Project Arena 0.3.21, from the asset viewer: https://jendoebelin.github.io/ProjectArena-public/#V26

In this file:
  av_bottom_3_m.glb
  av_bottom_3_f.glb
  open_design_bike_f.png
  open_design_bike_m.png
  open_soft_strip.png

The models are .glb (Blender: File > Import > glTF 2.0). Skinned parts carry the game's 9-bone avatar rig in its bind
pose; head parts are in head space (the origin between the eyes); gauntlets in the hand frame. Keep the material
names: they tell the game how to colour and light each part, and when you export from Blender (File > Export >
glTF 2.0, glTF Binary) tick Include > Custom Properties: the materials carry the game's exact settings there.

To make your own, start from the template pack (dl/project-arena-templates.zip on the viewer's page): its README says
what goes where. Send your file with the ID it replaces or adds to: a pull request (contrib/) or the Discord.

Art and sound: CC BY 4.0 (LICENSE-ASSETS.md in https://github.com/jendoebelin/ProjectArena-public).
