# Project Arena asset templates

Thanks for making something for Project Arena! Everything here is a reference you build on; nothing in this folder
ends up in the game as-is. Art you contribute is published under **CC BY 4.0** (see LICENSE-ASSETS.md in the repo):
anyone may use it with credit to you.

## Space and units (all files)

- Metres, **+Y up**, the avatar faces **-Z** (Blender's glTF importer turns this into Z up, facing -Y; export back with
  the default glTF settings and it comes out the same way).
- Keep the **material names** from the palette (list below). They are how the game knows which part takes the
  player's primary colour, which part glows, what is skin, and so on. Colours in the files are only previews.

## What goes where

| You are making | Start from | Notes |
|---|---|---|
| A top / outfit / shorts | `body_masculine.glb` and `body_feminine.glb` | Model on the body in its bind pose (arms out). Keep the armature: the game bends the outfit with the same 9 bones (torso, neck, head, both collarbones, upper arms and forearms), so every vertex needs weights (copy them from the body with Blender's Data Transfer modifier). Make one version per body. Max ~8,000 triangles each. |
| (top: what it covers) | | The top **replaces the body from the waist up**: chest, back and both arms to the wrists (the gauntlets cover the hands, the game draws the head). Any skin it leaves bare is part of your file (material `av_skin`, follow the template body's surface). It ends at the waist: Y = -0.431 m (feminine) / -0.439 m (masculine). |
| (shorts: what they cover) | | The shorts **replace the body from the waist down**: they start at the same waist line and carry the legs on to where the avatar's legs end, Y = -0.917 m (feminine) / -0.939 m (masculine), finished with the glowing fade ring (material `av_fade`). Bare leg below the hem is part of your file (`av_skin`). Without the legs the avatar stops at the hem. Copy the legs and the fade ring from `examples/av_bottom_1_f.glb` / `av_bottom_1_m.glb`. |
| (fit) | | Cloth follows the body's surface closely (3-15 mm off the skin, shrinkwrap it); hard plates up to ~25 mm. Fit each version to its own body (the feminine and masculine bodies differ in shape, not only in size). Use the template's coordinates exactly as they are: numbers from the game's source code are in other spaces. |
| A pattern or design on an outfit | `uv_layout_*.png` | Paint over the layout at 512 or 1024 px. Design masks use channels: **red** = the trim colour, **green** = glowing lines, **blue** = white accents. |
| Hair, a helmet, a cap, glasses, a face shield, a mask | `head_masculine.glb` / `head_feminine.glb` | Head space: the origin is between the eyes. Leave 3-6 mm between the part and the skin so nothing pokes through. One version per head (the four faces of a body share its skull: one fits them all). Max ~8,000 triangles. |
| A gauntlet / glove | `gauntlet_grip.glb` | The controller held in a glove, in the hand frame. Your gauntlet must enclose the controller (players hold a real one there). Right hand only; the game mirrors it for the left. Max ~8,000 triangles. |

The `examples/` folder has one finished game asset of each kind, exported from the game, so you can see how ours
are set up.

## Materials (palette names)

Avatars: `av_primary` (player's main colour, takes patterns), `av_primary_np` (main colour, no pattern),
`av_primary_dk` (darker main), `av_secondary`, `av_secondary_dk`, `av_glow` (glows in the glow colour), `av_trim`
(metallic trim colour), `av_skin`, `av_hair`, `av_hair_lock` (thin two-sided hair strands), `av_visor` (glass, takes
the visor tint), `av_dark`, `av_armor`, `av_armor_white`, `av_piping`, `av_cloth` / `av_cloth_dk` (matte fabric),
`av_fade` (the glowing ring where the avatar's legs end: shorts only).

Gauntlets: `gaunt_shell` (main colour plates), `gaunt_trim`, `gaunt_dark`, `gaunt_glow`, `glove`.

Every game asset has an ID in the asset viewer (https://jendoebelin.github.io/ProjectArena-public/): V for the
avatar builder's parts, P for props and gauntlets, T for textures, S for sounds. Look up the part you are changing or
adding to; each one there has its own download.

## Submitting

1. Export your model as **.glb** (File > Export > glTF 2.0, format "glTF Binary", with Include > Custom Properties
   ticked: a downloaded model's materials carry the game's exact settings there).
2. Put it in `contrib/<kind>/<your-asset-name>/` with a short `README.md`: what it is, the ID it replaces or the
   kind it adds to (from the viewer), your name or handle for the credit, and which bodies / heads it fits.
3. Open a pull request, or post it in the Discord with the ID. We check it in the headset; `tools/import_glb.py` turns
   it into a game model.

(These numbers and files are made from the game's own bodies: this pack, version 0.3.27.)
