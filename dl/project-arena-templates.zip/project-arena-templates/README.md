# Project Arena asset templates

Thanks for making something for Project Arena! Everything here is a reference you build on; nothing in this folder
ends up in the game as-is. Art you contribute is published under **CC BY 4.0** (see LICENSE-ASSETS.md in the repo):
anyone may use it with credit to you.

## Space and units (all files)

- Metres, **+Y up**, the avatar faces **-Z** (Blender's glTF importer turns this into Z up, facing -Y; export back with
  the default glTF settings and it comes out the same way).
- Keep the **material names** from the palette (list below). They are how the game knows which part takes the
  player's primary colour, which part glows, what is skin, and so on. Colours in the files are only previews.

## What goes where

| You are making | Start from | Notes |
|---|---|---|
| A top / outfit / shorts | `body_masculine.glb` and `body_feminine.glb` | Model on the body in its bind pose (arms out). Keep the armature: the game bends the outfit with the same 7 bones, so every vertex needs weights (copy them from the body with Blender's Data Transfer modifier). Make one version per body. Max ~8,000 triangles each. |
| A pattern or design on an outfit | `uv_layout_*.png` | Paint over the layout at 512 or 1024 px. Design masks use channels: **red** = the trim colour, **green** = glowing lines, **blue** = white accents. |
| Hair, a helmet, a cap, glasses, a face shield, a mask | `head_masculine.glb` / `head_feminine.glb` | Head space: the origin is between the eyes. Leave 3-6 mm between the part and the skin so nothing pokes through. One version per head. Max ~8,000 triangles. |
| A gauntlet / glove | `gauntlet_grip.glb` | The controller held in a glove, in the hand frame. Your gauntlet must enclose the controller (players hold a real one there). Right hand only; the game mirrors it for the left. Max ~8,000 triangles. |

The `examples/` folder has one finished game asset of each kind, exported from the game, so you can see how ours
are set up.

## Materials (palette names)

Avatars: `av_primary` (player's main colour, takes patterns), `av_primary_np` (main colour, no pattern),
`av_primary_dk` (darker main), `av_secondary`, `av_secondary_dk`, `av_glow` (glows in the glow colour), `av_trim`
(metallic trim colour), `av_skin`, `av_hair`, `av_hair_lock` (thin two-sided hair strands), `av_visor` (glass, takes
the visor tint), `av_dark`, `av_armor`, `av_armor_white`, `av_piping`, `av_cloth` / `av_cloth_dk` (matte fabric).

Gauntlets: `gaunt_shell` (main colour plates), `gaunt_trim`, `gaunt_dark`, `gaunt_glow`, `glove`.

## Submitting

1. Export your model as **.glb** (File > Export > glTF 2.0, format "glTF Binary").
2. Put it in `contrib/<kind>/<your-asset-name>/` with a short `README.md`: what it is, your name or handle for the
   credit, and which bodies / heads it fits.
3. Open a pull request. We check it in the headset; `tools/import_glb.py` turns it into a game model.
