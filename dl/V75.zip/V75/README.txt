V75 Peluru Layered Dress: An off-shoulder folk dress made with a member of the community: a flounced neckline, an embroidered bodice and a layered skirt that sways (the viewer shows it at rest), with hoop earrings that swing.

Project Arena 0.3.21, from the asset viewer: https://jendoebelin.github.io/ProjectArena-public/#V75

In this file:
  av_top_18_m.glb
  av_top_18_f.glb
  av_top_18e_m.glb
  av_top_18e_f.glb
  open_design_peluru_dress.png

The models are .glb (Blender: File > Import > glTF 2.0). Skinned parts carry the game's 9-bone avatar rig in its bind
pose; head parts are in head space (the origin between the eyes); gauntlets in the hand frame. Keep the material
names: they tell the game how to colour and light each part, and when you export from Blender (File > Export >
glTF 2.0, glTF Binary) tick Include > Custom Properties: the materials carry the game's exact settings there.

To make your own, start from the template pack (dl/project-arena-templates.zip on the viewer's page): its README says
what goes where. Send your file with the ID it replaces or adds to: a pull request (contrib/) or the Discord.

Art and sound: CC BY 4.0 (LICENSE-ASSETS.md in https://github.com/jendoebelin/ProjectArena-public).
